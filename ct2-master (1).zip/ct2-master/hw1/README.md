# Assignment no. 1: Predicting baseball game winners

Building a multiple linear regression model on the training data to predict the
number of wins for the team.
